/*
Projeto: Meios mobilidade eletrica;
Programador: Alexandre Vieira;
Numero:a26048;

Disciplina: Estruturas de dados avançadas;
Ano: 2022/2023;

Tipo de ficheiro : MAIN

*/



//Declaration of Includes;
#include <stdio.h>
#include "Function.h"
#include <stdlib.h>




/*-----------------------------Declaration of the Menus!-----------------------------*/

//Declaration of the First Menu to select the type of person that is using the program;
void userChoiceMenu()
{
    
system( "cls"); //This will clear the console;
printf("USER CHOISE MENU\n");

printf("1. - I'm a manager!\n");
printf("2. - I'm a client!\n");
printf("3. - Exit the menu.\n");
printf("\n Please enter your option: \n");
return;

}//End of userChoiseMenu;


//Manager menus;
void managerSubMenu() //ALL FUNCTIONS IMPLEMENTED!!!!!!!!!
{

system("cls");
printf("MANAGER ONLY MENU\n");

printf("1. - Insert new transport;\n");
printf("2. - Change an transport;\n");
printf("3. - Consult transport information;\n");
printf("4. - Remove a transport;\n");
printf("5. - Change your data;\n");
printf("6. - Exit the menu;\n");
printf("\n Please enter your option: \n");
return;

}//End of managerSubMenu;

void managerChangeVehicle() //ALL FUNCIONS IMPLEMENTED!
{

system("cls");
printf("MANAGER CHANGING DATA MENU\n");

printf("1. - Change the Serial Number value;\n");
printf("2. - Change the tyoe of vehicle value\n");
printf("3. - Change the Battery Percentage value\n");
printf("4. - Change the Autonomy value\n");
printf("5. - Change the Price value\n");
printf("6. - Change the Rental Status\n");
printf("7. - Exit the menu");
printf("\n Please enter your option\n");
return;


}// End of managerChangeVehicle

void managerChangeManager() //ALL FUNCIONS IMPLEMENTED!
{

system("cls");
printf("MANAGER CHANGING DATA MENU\n");

printf("1. - Change the Name ;\n");
printf("2. - Change the mobile Phone\n");
printf("3. - Exit the menu\n");
printf("\n Please enter your option\n");
return;


}// End of managerChangeVehicle


//Client menu;
void clientSubMenu() //
{

system("cls");
printf("CLIENT ONLY MENU\n");

printf("1. - Insert new client;\n");
printf("2. - Modify client data;\n");
printf("3. - Display autonomy ordenation;\n");
printf("4. - remove client;\n");
printf("5. - Rent an vehicle;\n");
printf("6. - Exit the menu;\n");
printf("\n Please enter your option: \n");
return;

}






/*--------------------------------------MAIN-------------------------------------------*/
int main()
{


/*--------------------------------Empty linked lists-----------------------------------*/

vehicle* newH = NULL; //This is the empty linked list necessary to "allocate" the information about new vehicles;
client* newC = NULL;//This is the empty linked list necessary to "allocate" the information about new clients;
manager* newM = NULL; //This is the empty linked list necessary to "allocate" the information about Manager;


/*---------------------Variables that are necessary for the code to work--------------*/


//vehicles variables;
int serial;
float bat, aut, pric;
char type [50];
char rentalStatus[4];


//manager Variables;
int badgeNumber;
float newName[50];
float newMobile[50];


//Client Variables;
char nameC[50];
char adress[50];
int nifC, mobile;
float mo;



//Menus Choise variables;
int option = -1;
int userChoiseOption = -1; //Variable that will serve to store the selected option from the first menu;
int managerChoiseOpt = -1; //Variable that will serve to store the selected option;
int changeValueVehicle = -1; //Option that we select to modify the data in the vehicles
int changeValueManager = -1; //Option that we select to modify the data in the Manager;
int clientChoiseOpt = -1;//Option that will serve to store the selected option


while (userChoiseOption != 3)
{
    userChoiceMenu();
    int optionOneVerification = scanf("d", &userChoiseOption);
    if (optionOneVerification == 1 && userChoiseOption > 0 && userChoiseOption <= 3)
{

    switch (userChoiseOption)
    {


    case 1: //Manager options will appear!!


    while (managerChoiseOpt != 6)
     {
        managerSubMenu();
        int managerChoiseOption = scanf("d", &managerChoiseOpt);
        if (managerChoiseOption == 1 && managerChoiseOpt > 0 && managerChoiseOpt <= 6)
        {

            switch(managerChoiseOpt) 
            {

                case 1: //Insert new vehicle (MANAGER -> TRANSPORTS);

                printf("Please type an valid serial number for the vehicle: \n");
                scanf("%d",&serial); 

                printf("Please type an valid type of transport: \n");
                scanf("%[^\n]s",type); //This means that it will read ultil it apears an next line, like when we it enter!

                printf("Please type the battery percentage: \n");
                scanf("%f",&bat);

                printf("Please type the autonomy that the vehicle as: \n");
                scanf("%f",&aut);

                printf("Please type the cost of the vehicle for the client: ");
                scanf("%f", &pric);

                printf("Pelase type Yes for ocupied or NO for free");
                scanf("%[^\n]s", rentalStatus );
                
                newH = newVehicle(newH,serial,type,bat,aut,pric,rentalStatus);
                break;



                case 2: //Change an value of an vehicle:

                while(changeValueVehicle != 6 ) //SUBMENU OF THE CHANGING DATA OF VEHICLES
                {
                    managerChangeVehicle();
                    int optionChangeVehicles = scanf("d", &changeValueVehicle);
                    if(optionChangeVehicles == 1 && changeValueVehicle > 0 && changeValueVehicle <= 6)
                    {


                        printf("\nPlease Type the serial number that you want to edit\n");
                        scanf("%d", serial);

                        switch (changeValueVehicle)
                        {

                         case 1: //Modify Serial Number:

                         printf("Please type the serial number :\n");
                         scanf("%d", &serial);

                         changeValueVehicle = option;//For selection of the Option in the function;

                          newH = modifyVehicle (newH, option, serial, type, bat,  aut, pric, rentalStatus);
                            break;
                        

                         case 2 : //Modify Vehicle Type:

                         printf("Please type an valid type of transport: \n");
                         scanf("%[^\n]s",type); //This means that it will read ultil it apears an next line, like when we it enter!

                         changeValueVehicle = option;//For selection of the Option in the function;

                            newH = modifyVehicle (newH, option, serial, type, bat,  aut, pric, rentalStatus);
                            break;


                         case 3 : //Modify battery:

                         printf("Please type the battery percentage: \n");
                         scanf("%f",&bat);

                         changeValueVehicle = option;//For selection of the Option in the function;

                          newH = modifyVehicle (newH, option, serial, type, bat,  aut, pric, rentalStatus);
                            break;


                         case 4 : //Modify battery:

                         printf("Please type the autonomy that the vehicle as: \n");
                         scanf("%f",&aut);

                         changeValueVehicle = option;//For selection of the Option in the function;

                          newH = modifyVehicle (newH, option, serial, type, bat,  aut, pric, rentalStatus);
                            break;


                         case 5 : //Modify price:

                         printf("Please type the cost of the vehicle for the client: ");
                         scanf("%f", &pric);

                         
                         changeValueVehicle = option;//For selection of the Option in the function;

                          newH = modifyVehicle (newH, option, serial, type, bat,  aut, pric, rentalStatus);
                            break;


                         case 6:

                         printf("Pelase type Yes for ocupied or NO for free");
                         scanf("%[^\n]s", rentalStatus );

                         changeValueVehicle = option;//For selection of the Option in the function;

                          newH = modifyVehicle (newH, option, serial, type, bat,  aut, pric, rentalStatus);
                         break;


                         case 7 : //Exit the menu:
                         break;


                        } //End of switch case for Modify Menu;


                    }//End of if statement;


                }//End of manager change vehicle while statement;


                case 3: 

                 printVehicleList(newH);
                 break;


                case 4: //remove vehicle;

                printf("Please type the serial number of the vehicle that you need to remove:");
                scanf("%d", &serial);

                newH = removeVehicle(newH, serial);
                break;


                case 5:

                while(changeValueVehicle != 3 ) //SUBMENU OF THE CHANGING DATA OF VEHICLES
                {
                    managerChangeManager();
                    int optionChangeManager = scanf("d", &changeValueManager);
                    if(optionChangeManager == 1 && changeValueManager > 0 && changeValueManager <= 3)
                    {

                        switch (changeValueManager)
                        {

                         case 1: //Modify Name;

                         printf("Please type the Name :\n");
                         scanf("%[^\n]s",newName);

                         changeValueManager = option;//For selection of the Option in the function;

                         newM = modifyManager(newM, option, badgeNumber, newName, newMobile);
                            break;



                            case 2 : //Modify mobile phone;

                            printf("Please type the badgeNumber :\n");
                            scanf("%d", &newMobile);

                         changeValueManager = option;//For selection of the Option in the function;

                         newM = modifyManager(newM, option, badgeNumber, newName, newMobile);
                         break;


                            case 3 :
                            break;


                        }//End of if statement;


                }//End of while statemente;

        
                case 6:
                break;

            }//End of switch statement from manager subMenu;

        }//End of if statement form the manager subMenu;

     }//End of Manager subMenu switch Statement;


     case 2:

     while (clientChoiseOpt != 3)
     {

     clientSubMenu();

     int optionClientVerification = scanf("d", &clientChoiseOpt);
     if (optionClientVerification == 1 && clientChoiseOpt > 0 && clientChoiseOpt <= 3)
     {


        switch (clientChoiseOpt)
        {

            case 1://Insert new CLient;

                printf("Please type an valid name for the client: \n");
                scanf("%[^\n]s", nameC); 

                printf("Please type an valid Adress for the client: \n");
                scanf("%[^\n]s",adress); 

                printf("Please an valid nif: \n");
                scanf("%d",&nifC);

                printf("Please type an valid mobile number: \n");
                scanf("%d",&mobile);

                printf("Please type an valid moneyy (The more the better :) ");
                scanf("%f", &mo);

                newC = newClient(newC, nameC, adress, nifC, mobile, mo);
                break;


            case 2: //Modify client data;


            case 3: //Display autonomy ordenation;


            case 4: //remove client;


            case 5: //Rent an vehicle;


            case 6: //Exit the menu;
            break;


        }//End of subMenu Client Choise;


     }//End of if;


     }//End of Client Menu;


     case 3:
          storeVehicleData (newH);
          storageClientData (newC);
          storageManagerData (newM);
                break;

    }//End of first switch statement;


}//end of  first If statement;


}//End of While statement;


}


}