/*
Projeto: Meios mobilidade eletrica;
Programador: Alexandre Vieira;
Numero:a26048;

Disciplina: Estruturas de dados avançadas;
Ano: 2022/2023;

Tipo de ficheiro : HEADER

*/





//Declaration of Includes to connect the functions;
#include <stdio.h>



/*---------------------------Declaration of the Structs!-----------------------*/



//This struct has the purpuse to store the scooters and the bicycles information;
typedef struct vehicleInformationList
{

int serialNumber;
char type[20];
float bateryPercentage;
float autonomy;
float price;
char rentalStatus[4]; //yes or no;

struct vehicleInformationList* nextVehicle;
}vehicle;


//This struct has the purpuse to store the client information (aka:Personal Data);
typedef struct clientInfo
{
char nameC[50];
char adress[50];
int nif;
int mobileNumber;
float money;

struct clientInfo* nextClient;
}client;


//This struct has the purpuse to store the Manager information (aka:Personal Data);
typedef struct managerInfo
{
char Name[50]; //It's Name and not name to me to not have mistakes!;
int badgeNumber;
int mobileNumber;

struct managerInfo* nextManager;
}manager;


//This struct has the purpuse to store information of dates ;
typedef struct generalDate
{

int day;
int month;
int year;

}date;






/*-------------------------------FUNCTION CONNECTION-----------------------------------*/


//Vehicle Fucntions:
vehicle* newVehicle(vehicle* first, int serial, char type[], float bat, float aut, float pric, char rentalStatus[]); //Make an new allocation for an new vehicle! :)


int verifyVehicle(vehicle* first, int serial); // Verifies if the the serial number exists for prouf of the existance of the vehicle!


int searchVehicle(vehicle* first, int serial); //verifyes the same thing as above but returns the adress instead of an 1 or 0!


vehicle* removeVehicle (vehicle* first, int serial); //remove an list!


int storeVehicleData (vehicle* first); //Saves the data on an .txt file type!


vehicle* modifyVehicle (vehicle* first, int option, int serial, char type[], float bat, float aut, float pric, char rentalStatus[]);//Changes any type of data on a vehicle that you want!


int readVehicles(vehicle* first, int serial);//Function to read the values to an list;


vehicle* printVehicleList(vehicle* first); //does the printf of the informations;


int registerRental(vehicle* headVehicle, client* headClient, int serial, int km, char nam, date rentalDate, float pric); //Does the register of the data;


vehicle* fromTheHigherAutonomy (vehicle* first); //Does the ordenation;








//Client Functions:
int storageClientData (client* first); //Storage an client;


client* newClient(client* first, char nameC[], char adress[], int nifC, int mobile, float mo); // Make an new allocation for an client!


int verifyClients(client* first, int nifC); // Verifies if the the serial number exists for prouf of the existance of the client!


int searchClient(client* first, int nifC);//Search for an nif


client* removeClient (client* first, int nifC); //Remove an client by is nif;


client* modifyClient (client* first, int option, char nameC[], char adress[], int nifC, int mobile, float mo); //Function to modify elemnts of clients


int readClients(vehicle* first, int nifC); //Function to read the clients data forman an txt file;





//Manager Functions:
int storageManagerData(manager* first);


manager* newManager(manager* first, char name[], int badgeNumber, int mobileNumber); //Function to insert a new MANAGER;


int verifyManagers(manager* first, int badgeNumber);// Function to verify the existence of a manager by badge number


manager* searchManager(manager* first, int badgeNumber); //Function to verify the existance of an Manager and return the list;


manager* removemanager (manager* first, int badge);//Function to remove an Manager;


manager* modifyManager(manager* first, int option, int badgeNumber, char newName[], char newMobile[]);//Function to modify the manager data;


manager* readManagers();//function to read the manager data;




/*
//Nedded VAriables;
    int serial,km ;
    char nam[50];
    date rentalDate;
    float rentalPrice;

    // Ask for rental details
    printf("Enter vehicle serial number: ");
    scanf("%d", &serial);

    printf("Enter client name: ");
    scanf("%s", nam);

    printf("Enter rental date (DD/MM/YYYY): ");
    scanf("%d/%d/%d", &rentalDate.day, &rentalDate.month, &rentalDate.year);

    printf("Enter rental kilometers: ");
    scanf("%d", &km);
*/