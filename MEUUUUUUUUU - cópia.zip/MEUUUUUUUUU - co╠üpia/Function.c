
/*
Projeto: Meios mobilidade eletrica;
Programador: Alexandre Vieira;
Numero:a26048;

Disciplina: Estruturas de dados avançadas;
Ano: 2022/2023;

Tipo de ficheiro : FUNCTIONS

*/



//Declaration of Includes for the Functions to work;
#include <stdlib.h>
#include "Function.h"
#include <string.h>


/*-------------------------------------------------Vehicles FUNCTIONS-----------------------------------------*/


//Function to insert a new Vehicle Record;
vehicle* newVehicle(vehicle* first, int serial, char type[], float bat, float aut, float pric, char rentalStatus[])
{

/*To insert an new record we need first to make shure that its pointing to an vhicle that exists, 
 so i will follow the teacher example and make an small function to verify;*/

 if (!verifyVehicle(first, serial))  
  {
    vehicle* new = malloc(sizeof(struct vehicleInformationList));

  if (new != NULL)
  {

    new -> serialNumber = serial;             
    strcpy(new -> type, type);
    new -> bateryPercentage = bat;
    new -> autonomy = aut;
    new -> price = pric;
    strcpy(new -> rentalStatus, rentalStatus);
    new -> nextVehicle = first;

    return(new);

  }//End of second if statement;

 }else return(first); //End of first if statement;

}//End of the newVehicle function;


//Function to verify the existance of an vehicle;  
int verifyVehicle(vehicle* first, int serial)
{
    
 while(first!=NULL)  //if there is a person with the same code as the one we want to enter, then it returns to the console;
  {

    if (first -> serialNumber == serial) 
    {
    return(1);
    }

    first = first->nextVehicle;

  }//End of while statement;

 return(0);

}


//Function that does the same thing as above but instead of return an 1 or 0 it returns the first itself;
int searchVehicle(vehicle* first, int serial)
{
    
 while(first!=NULL)  //if there is a person with the same code as the one we want to enter, then it returns to the console;
  {

    if (first -> serialNumber == serial) 
    {
    return(first);
    }

    first = first->nextVehicle;

  }//End of while statement;

 return(0);

}


//Function to remove an Vhehicle;
vehicle* removeVehicle (vehicle* first, int serial)
{

    vehicle* theBackOne = first;
    vehicle* actual = first;
    vehicle* helper;



//If the list is empty:
if (actual == NULL) 
{

//printf("\n Theres no number to remove or there's an error on the linked list, please verify FUNCTIONS.H!! \n");
return(NULL);

}//End of if statement;


//If the serial number is found in the first record, then it will remove it and the adress starts to point to the next one for connection of the list:
if(actual -> serialNumber = serial)
{

helper = actual -> nextVehicle; // this means that it will modify to the next list the "actual" was in the first list and the number was found so, the address of the "helper" will move to the next list;
free(actual); //This means that will delete because the number was found;
return(helper);

}//End of if statement


//It will go through the list looking for the number while it does not find NULL;
{
    while (( actual != NULL ) && ( actual -> serialNumber != serial))  
  {

    theBackOne = actual;
    actual = actual->nextVehicle; //if it checks the list and doesn't find any value then it goes to the next list to check the existence of the value. (Same thing as saying that x=x+1);

  }


 //if the vhecile was not found:
  if (actual==NULL)
  {

     return(first);

  } 
  
  else // If it not finds the value...
  { 

    theBackOne -> nextVehicle = actual -> nextVehicle;
   free(actual);
   return(first);

  }//end of else statement;

}//End of if statement from removeVehicle

}//End of remove Vehicle function;


//Function to store the data of the vehicles;
int storeVehicleData (vehicle* first)
{
    
    FILE* vehicleStorage = fopen ( "vehiclesStorageFile.txt", "w"); //If there is no file with that name it will create one!

    if( vehicleStorage == NULL)
    {
        //printf(" \n It has ocurred an ERROR while opening the file!!! \n ");
    }

    if(vehicleStorage != NULL)
    {
        vehicle* helper = first;
        while(helper != NULL)
        {

            fprintf(vehicleStorage, 
            "%d; %s; %f; %f; %f\n", 
            helper -> serialNumber, helper -> type, helper -> bateryPercentage, helper -> autonomy, helper -> price );

            helper = helper -> nextVehicle;

        }//End of while statement

        fclose(vehicleStorage);
        return(1);

    }//End of if setatement

}// End of storage Vheicle Data funcion;


//change the values form the vehicle ;
vehicle* modifyVehicle (vehicle* first, int option, int serial, char type[], float bat, float aut, float pric, char rentalStatus[])
{

    vehicle* helper = first;
 
    if(searchVehicle(first, serial) && first -> serialNumber == serial)
    {

        //Menu to choise what to modify
        if( option = 1)
        {
             helper -> serialNumber = serial;  
        }

         if( option = 2)
        {
             strcpy( helper -> type, type);
        }

         if( option = 3)
        {
             helper -> bateryPercentage = bat;
        }

         if( option = 4)
        {
             helper -> autonomy = aut;
        }

         if( option = 5)
        {
             helper -> price = pric;
        }

        if( option = 6)
        {
            strcpy(helper -> rentalStatus, rentalStatus);
        }
     
     }//End of if statement;


} //End of modify vehicle function;


//Function to read Values;
int readVehicles(vehicle* first, int serial)
{

FILE* vehicleScan = fopen("vehiclesStorageFile.txt", "r");


char type[20];
char rentalStatus[4];
float bat,aut,pric;

if( vehicleScan == NULL)
{
//Printf("ERROR!!!!!");
}


if (vehicleScan != NULL)
{
  vehicle* helper = NULL;

  while( !feof(vehicleScan)) 
  {
    fscanf(vehicleScan, "%d; %s; %f; %f; %f; %s\n", &serial, type, &bat, &aut, &pric, rentalStatus );
    helper = newVehicle(helper,serial,type,bat,aut,pric,rentalStatus);
  }

  fclose(vehicleScan);

 }
 return first;
 return 0;

  
}// end of the scan function;


//Function to print the values;
vehicle* printVehicleList(vehicle* first) 
{

    vehicle* helper = first;

    while (helper != NULL) {
        printf("Serial Number: %d\n", helper -> serialNumber);
        printf("Type: %s\n", helper -> type);
        printf("Battery Percentage: %.2f\n", helper -> bateryPercentage);
        printf("Autonomy: %.2f\n", helper -> autonomy);
        printf("Price: %.2f\n", helper -> price);
        printf("Rental Status: %s\n", helper -> rentalStatus);
        printf("--------\n");

        helper = helper -> nextVehicle;
    }
 
 return first;
}//End of printVehicleList;


//this funcion will make an registy of the rental activity from the clients option;
int registerRental(vehicle* headVehicle, client* headClient, int serial, int km, char nam, date rentalDate, float pric) 
{


    //Search for the vehicle and client in the linked lists
    vehicle* currentVehicle = headVehicle -> nextVehicle;
    while (currentVehicle != NULL && currentVehicle -> serialNumber != serial) 
    {

        currentVehicle = currentVehicle -> nextVehicle;

    }

    client* currentClient = headClient -> nextClient;
    while (currentClient != NULL && strcmp(currentClient -> nameC, nam) != 0) 
    {

        currentClient = currentClient -> nextClient;

    }

    //Check if the vehicle and client were found
    if (currentVehicle == NULL) 
    {

        //printf("Error: vehicle with serial number %d not found.\n", serial);
        return;

    }

    if (currentClient == NULL) 
    {

        //printf("Error!!!!!!!!!! client with name %s not found.\n", nam);
        return;

    }


    //Check if the vehicle is available for rent
    if (strcmp(currentVehicle->rentalStatus, "yes") != 0) 
    {

        //printf("Error: vehicle with serial number %d is not available for rent.\n", serial);
        return;

    }


    //Calculate rental pric
    pric = km * currentVehicle -> price;

    //Check if the client has enough money to pay for the rental
    if (currentClient -> money < pric) 
    {

        //printf("Error: client %s does not have the enough money to pay for the rental (price is %.2f).\n", nam, pric);
        return;

    }


    //Updatioiu vehicle and client information
    strcpy(currentVehicle -> rentalStatus, "no");
    currentClient -> money -= pric;

    //Save rental information to file
    FILE* file = fopen("rentals.txt", "a");
    if (file == NULL) 
    {

        printf("Error: could not open file rentals.txt for writing.\n");
        return;

    }

    fprintf(file, "%d; %s; %d/%d/%d; %.2f\n", serial, nam, rentalDate.day, rentalDate.month, rentalDate.year, pric);

    fclose(file);

    //printf("Rental registered successfully.\n");
}//ENd of rental register;


//This function will reajust from the high autonomy for the lower autonomy;
vehicle* fromTheHigherAutonomy (vehicle* first)
{
    

    //Necessary thing to "chase" the value;
    vehicle* theBackOne = first;
    vehicle* actual;
    vehicle* biggerAutonomy;

    
    vehicle* novaLista = NULL;

    //removing elements to another struct
    while (first != NULL) 
    {
        
        biggerAutonomy = first;
        actual = first -> nextVehicle;

        while (actual != NULL) 
        {
            if (actual -> autonomy > biggerAutonomy -> autonomy) {
                biggerAutonomy = actual;
            }
            actual = actual -> nextVehicle;

        }


        //Pulling the bigger autonomy
        if (biggerAutonomy == first) 
        {

            first = first -> nextVehicle; 

        }


        else 
        {

            theBackOne -> nextVehicle = biggerAutonomy -> nextVehicle;
        }


        // ordenation
        if (novaLista == NULL || biggerAutonomy -> autonomy >= novaLista -> autonomy) 
        
        {
            biggerAutonomy -> nextVehicle = novaLista;
            novaLista = biggerAutonomy;
        }

        else 
        
        {
            actual = novaLista;
            while (actual -> nextVehicle != NULL && actual -> nextVehicle -> autonomy < biggerAutonomy -> autonomy) 
            {

                actual = actual->nextVehicle;

            }
            
            biggerAutonomy -> nextVehicle = actual -> nextVehicle;
            actual -> nextVehicle = biggerAutonomy;

        }

      
        theBackOne = biggerAutonomy;

    }

    
    return (first);

}//End of fromTheHigherAutonomy






/*-------------------------------------------------CLIENT FUNCTIONS-----------------------------------------*/


//Function to store the data of the clients:
int storageClientData (client* first)
{

    FILE* clientStorage = fopen ( "clientStorageFile.txt", "w"); //If there is no file with that name it will create one!

    if( clientStorage == NULL)
    {
        printf(" \n It has ocurred an ERROR while opening the file!!! \n ");
    }

    if(clientStorage != NULL)
    {
        client* helper = first;
        while(helper != NULL)
        {

            fprintf(clientStorage, 
            "%s; %s; %d; %d; %f\n", 
            helper -> nameC, helper -> adress, helper -> nif, helper -> mobileNumber, helper -> money );

            helper = helper -> nextClient;

        }//End of while statement

        fclose(clientStorage);
        return(1);

    }//End of if setatement

}//End of storage Client Data function;


//Function to insert a new Client ( R U A NEW CLIENT?):
client* newClient(client* first, char nameC[], char adress[], int nifC, int mobile, float mo)
{

/*To insert an new record we need first to make shure that its pointing to an vhicle that exists, 
 so i will follow the teacher example and make an small function to verify;*/

 if (!verifyClients (first, nifC))  
  {
    client* new = malloc(sizeof(struct clientInfo));

  if (new != NULL)
  {

    strcpy (new -> nameC, nameC);         
    strcpy (new-> adress, adress);
    new -> nif = nifC;
    new -> mobileNumber = mobile;
    new -> money = mo;
    new -> nextClient = first;
    
    return(new);

  }//End of second if statement;

 }else return(first); //End of first if statement;

}//End of the new Client function;


//Function to verify the existance of an client;  
int verifyClients(client* first, int nifC)
{
    
 while(first!=NULL)  
  {

    if (first -> nif == nifC) 
    {
    return(1);
    }

    first = first -> nextClient;

  }//End of while statement;

 return(0);

}


//Function to verify the existance of an client and return the list;
int searchClient(client* first, int nifC)
{
    
 while(first!=NULL)  //se não existir uma pessoa com o Nif igual ao que queremos introduzir;
  {

    if (first -> nif == nifC) 
    {
      return(first);
    }

    first = first -> nextClient;

  }//End of while statement;

 return(0);

}


//Function to remove an Client;
client* removeClient (client* first, int nifC)
{

    client* theBackOne = first;
    client* actual = first;
    client* helper;



//If the list is empty:
if (actual == NULL) 
{

//printf("\n Theres no number to remove or there's an error on the linked list, please verify FUNCTIONS.H!! \n");
return(NULL);

}//End of if statement;


//If the serial number is found in the first record, then it will remove it and the adress starts to point to the next one for connection of the list:
if(actual -> nif = nifC)
{

helper = actual -> nextClient; // this means that it will modify to the next list the "actual" was in the first list and the number was found so, the address of the "helper" will move to the next list;
free(actual); //This means that will delete because the number was found;
return(helper);

}//End of if statement


//It will go through the list looking for the number while it does not find NULL;
{
    while (( actual != NULL ) && ( actual -> nif != nifC))  
  {

    theBackOne = actual;
    actual = actual -> nextClient; //if it checks the list and doesn't find any value then it goes to the next list to check the existence of the value. (Same thing as saying that x=x+1);

  }


 //if the vhecile was not found:
  if (actual==NULL)
  {

     return(first);

  } 
  
  else // If it not finds the value...
  { 

    theBackOne -> nextClient = actual -> nextClient;
   free(actual);
   return(first);

  }//end of else statement;

}//End of if statement from removeVehicle

}//End of remove Vehicle function;


//Fucntion to modfy vclient data
client* modifyClient (client* first, int option, char nameC[], char adress[], int nifC, int mobile, float mo)
{

    client* helper = first;
 
    if(searchClient(first, nifC) && first -> nif == nifC)
    {

        //Menu to choise what to modify
        if( option = 1)
        {
             strcpy( helper -> nameC, nameC); 
        }

         if( option = 2)
        {
             strcpy( helper -> adress, adress);
        }

         if( option = 3)
        {
             helper -> nif = nifC;
        }

         if( option = 4)
        {
             helper -> mobileNumber = mobile;
        }

         if( option = 5)
        {
             helper -> money =  mo;
        }

     
     }//End of if statement;


} //End of modify vehicle function;


//Function to read the clients data:
int readClients(vehicle* first, int nifC)
{

FILE* clientScan = fopen("clientStorageFile.txt", "r+");


char nameC[50];
char adress[50];
int nifC,mobile;
float mo;

if(clientScan == NULL)
{
//Printf("ERROR!!!!!");
}


if (clientScan != NULL)
{
  vehicle* helper = NULL;

  while( !feof(clientScan)) 
  {
    fscanf(clientScan, "%s; %s; %d; %d; %f\n", nameC, adress, &nifC, &mobile, &mo);
    helper = newClient(helper,nameC, adress, nifC, mobile, mo);
  }

  fclose(clientScan);

 }return(first);

  return 0;
}// end of the rental function;






/*-------------------------------------------MANAGER FUNCTION--------------------------------------------*/


//Storage of the Manager Data;
int storageManagerData(manager* first)
{

    FILE* managerStorage = fopen("managerStorageFile.txt", "w"); //If there is no file with that name it will create one!

    if (managerStorage == NULL)
    {
        printf("\n It has occurred an ERROR while opening the file!!! \n ");
    }

    if (managerStorage != NULL)
    {
        manager* helper = first;
        while (helper != NULL)
        {

            fprintf(managerStorage,
                    "%s; %d; %d\n",
                    helper->Name, helper->badgeNumber, helper->mobileNumber);

            helper = helper->nextManager;

        }//End of while statement

        fclose(managerStorage);
        return(1);

    }//End of if statement

}//End of storage Manager Data function;


//Function to insert a new MANAGER;
manager* newManager(manager* first, char name[], int badgeNumber, int mobileNumber)
{
    // Check if the badgeNumber already exists
    if (verifyManagers(first, badgeNumber))
    {
        printf("Manager with badge number %d already exists.\n", badgeNumber);
        return first;
    }

    manager* newManager = (manager*)malloc(sizeof(manager));

    if (newManager != NULL)
    {
        strcpy(newManager->Name, name);
        newManager->badgeNumber = badgeNumber;
        newManager->mobileNumber = mobileNumber;
        newManager->nextManager = first;
        
        printf("Manager with badge number %d added successfully!\n", badgeNumber);
        return newManager;
    }
    else
    {
        printf("Failed to add new manager.\n");
        return first;
    }
}


// Function to verify the existence of a manager by badge number
int verifyManagers(manager* first, int badgeNumber)
{
    while(first != NULL)  
    {
        if (first->badgeNumber == badgeNumber) 
        {
            return 1;
        }
        first = first->nextManager;
    }
    return 0;
}


//Function to verify the existance of an Manager and return the list;
manager* searchManager(manager* first, int badgeNumber)
{
    while(first != NULL)  
    {
        if (first->badgeNumber == badgeNumber) 
        {
            return first;
        }
        first = first->nextManager;
    }
    return NULL;
}


//Function to remove an Manager;
manager* removemanager (manager* first, int badge)
{

    manager* theBackOne = first;
    manager* actual = first;
    manager* helper;



//If the list is empty:
if (actual == NULL) 
{

//printf("\n Theres no number to remove or there's an error on the linked list, please verify FUNCTIONS.H!! \n");
return(NULL);

}//End of if statement;


//If the serial number is found in the first record, then it will remove it and the adress starts to point to the next one for connection of the list:
if(actual -> badgeNumber = badge)
{

helper = actual -> nextManager; //this means that it will modify to the next list the "actual" was in the first list and the number was found so, the address of the "helper" will move to the next list;
free(actual); //This means that will delete because the number was found;
return(helper);

}//End of if statement


//It will go through the list looking for the number while it does not find NULL;
{
    while (( actual != NULL ) && ( actual -> badgeNumber != badge))  
  {

    theBackOne = actual;
    actual = actual->nextManager; //if it checks the list and doesn't find any value then it goes to the next list to check the existence of the value. (Same thing as saying that x=x+1);

  }


 //if the vhecile was not found:
  if (actual==NULL)
  {

     return(first);

  } 
  
  else // If it not finds the value...
  { 

    theBackOne -> nextManager = actual -> nextManager;
   free(actual);
   return(first);

  }//end of else statement;

}//End of if statement from removeVehicle

}//End of remove Vehicle function;


//Function to modify the manager data;
manager* modifyManager(manager* first, int option, int badgeNumber, char newName[], char newMobile[])
{
    manager* helper = searchManager(first, badgeNumber);

    if (helper != NULL)
    {
        // Menu to choose what to modify
        switch(option)
        {
            case 1:
                strcpy(helper->Name, newName);
                break;
            case 2:
                strcpy(helper->mobileNumber, newMobile);
                break;
            default:
                printf("Invalid option!\n");
                break;
        }
    }
    else
    {
        printf("Manager with badge number %d not found.\n", badgeNumber);
    }

    return first;
}


//function to read the manager data;
manager* readManagers()
{
    FILE* managerFile = fopen("managerStorageFile.txt", "r");

    if (managerFile == NULL)
    {
        printf("Error opening manager file!\n");
        return NULL;
    }

    manager* first = NULL;
    char name[50], mobile[50];
    int badgeNumber;

    while (fscanf(managerFile, "%d; %s; %s\n", &badgeNumber, name, mobile) != EOF)
    {
        first = newManager(first, name, badgeNumber, mobile);
    }

    fclose(managerFile);

    return first;
}